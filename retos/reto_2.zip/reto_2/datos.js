import {datos} from "./datos.js";

//instanciar el objeto del tipo dato

const myData = new datos();
const Datos = myData.getDatos();
console.log(Datos);